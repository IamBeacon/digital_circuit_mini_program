// pages/simulation/simulation.js
var ctx = wx.createCanvasContext('myCanvas', this)
var windowHeight=wx.getSystemInfoSync().windowHeight //获取设备的可使用窗口高度，单位px
var windowWidth=wx.getSystemInfoSync().windowWidth //获取设备的可使用窗口宽度，单位px
var x=windowWidth/100
var y=windowHeight*0.6/100
var tar_id;//在画布上显示的电路id名称在CirSelect触发时赋值到此名称
var box_1=0,box_2=0,box_3=0,box_4=0,box_5=0,box_6=0,box_7=0,box_8=0,box_9=0,box_10=0,box_11=0,box_12=0,box_13=0,box_14=0;
var tall=1;//计数器计数
/* 方框颜色样式，a,b代表小方块左上角坐标。c可填0或1，0代表低电平，1代表高电平 */
function discol(a,b,c){
  if(c==0){
  ctx.setFillStyle('Crimson')
  ctx.fillRect(a*x, b*y, 5*x, 5*y)
  ctx.setFontSize(18)
  ctx.setFillStyle('black')
  ctx.fillText('0', (a+2.5)*x, (b+4.5)*y)
  }else if(c==1){
  ctx.setFillStyle('Lime')
  ctx.fillRect(a*x, b*y, 5*x, 5*y)
  ctx.setFontSize(18)
  ctx.setFillStyle('black')
  ctx.fillText('1', (a+2.5)*x, (b+4.5)*y)
  
}}
/* 定义函数，输入方框左上角坐标可自动判断触摸到屏幕的点是否在该方框内,a,b为方框的坐标。c,d为触摸点的坐标 */
function judg(a,b,c,d){
  if(c>(a-1.25)*x && c<(a+6.25)*x && d>(b-1.25)*y && d<(b+6.25)*y){
    return 1;
  }else{
    return 0;
  }
}
/* 仿真页面画布提示 */
function begin(){
  ctx.setFontSize(40)
    ctx.setTextAlign('right')
    ctx.fillText('⇱', 15*x, 14*y)
    ctx.setTextAlign('left')
    ctx.fillText('⇲', 85*x, 94*y)
    ctx.setFontSize(20)
    ctx.setTextAlign('center')
    ctx.fillText('器件仿真区域', 50*x, 44*y)
    ctx.fillText('可在下面滚动栏选择要仿真的器件', 50*x, 55*y)
}
/* 与运算框图 */
function andcir(){
  ctx.strokeRect(25*x,42.5*y,5*x,5*y)
  ctx.strokeRect(25*x,52.5*y,5*x,5*y)
  ctx.strokeRect(65*x,47.5*y,5*x,5*y)
  ctx.moveTo(30*x,45*y)
  ctx.lineTo(40*x,45*y)
  ctx.moveTo(30*x,55*y)
  ctx.lineTo(40*x,55*y)
  ctx.moveTo(52.5*x,42.5*y)
  ctx.lineTo(40*x,42.5*y)
  ctx.lineTo(40*x,57.5*y)
  ctx.lineTo(52.5*x,57.5*y)
  ctx.arcTo(60*x,57.5*y,60*x,50*y,7.5*y)
  ctx.arcTo(60*x,42.5*y,52.5*x,42.5*y,7.5*y)
  ctx.lineTo(52.5*x,42.5*y)
  ctx.moveTo(60*x,50*y)
  ctx.lineTo(65*x,50*y)
  ctx.stroke()
  ctx.setFontSize(20)
  ctx.setTextAlign('center')
  ctx.fillText('A', 43*x, 47*y)
  ctx.fillText('B', 43*x, 56.5*y)
}
/* 或运算框图 */
function orcir(){
  ctx.strokeRect(25*x,42.5*y,5*x,5*y)
  ctx.strokeRect(25*x,52.5*y,5*x,5*y)
  ctx.strokeRect(65*x,47.5*y,5*x,5*y)
  ctx.moveTo(30*x,45*y)
  ctx.lineTo(40*x,45*y)
  ctx.moveTo(30*x,55*y)
  ctx.lineTo(40*x,55*y)
  ctx.moveTo(57.5*x,50*y)
  ctx.lineTo(65*x,50*y)
  ctx.moveTo(50*x,42.5*y)
  ctx.lineTo(37.5*x,42.5*y)
  ctx.arcTo(40*x,42.5*y,40*x,45*y,2.5*y)
  ctx.lineTo(40*x,55*y)
  ctx.arcTo(40*x,57.5*y,37.5*x,57.5*y,2.5*y)
  ctx.lineTo(50*x,57.5*y)
  ctx.arcTo(57.5*x,57.5*y,57.5*x,50*y,7.5*y)
  ctx.arcTo(57.5*x,42.5*y,50*x,42.5*y,7.5*y)
  ctx.lineTo(50*x,42.5*y)
  ctx.stroke()
  ctx.setFontSize(20)
  ctx.setTextAlign('center')
  ctx.fillText('A', 43.5*x, 47*y)
  ctx.fillText('B', 43.5*x, 56.5*y)
}
/* 非运算框图 */
function notcir(){
  ctx.strokeRect(30*x,47.5*y,5*x,5*y)
  ctx.strokeRect(65*x,47.5*y,5*x,5*y)
  ctx.moveTo(35*x,50*y)
  ctx.lineTo(45*x,50*y)
  ctx.lineTo(45*x,42.5*y)
  ctx.lineTo(55*x,50*y)
  ctx.lineTo(45*x,57.5*y)
  ctx.lineTo(45*x,50*y)
  ctx.moveTo(65*x,50*y)
  ctx.lineTo(57.5*x,50*y)
  ctx.arc(56.25*x,50*y,1.25*x,0,2.5*Math.PI)
  ctx.stroke()
  ctx.setFontSize(20)
  ctx.setTextAlign('center')
  ctx.fillText('A', 47.5*x, 52*y)
}
/* 4线-2线优先编码器框图 */
function fourtwocir(){
  ctx.strokeRect(40*x,27.5*y,20*x,40*y)
  ctx.setTextAlign('center')
  for(var i=0;i<6;i++){
    if(i<4){
      ctx.strokeRect(25*x,(30+i*10)*y,5*x,5*y)
      ctx.moveTo(30*x,(32.5+i*10)*y)
      ctx.lineTo(40*x,(32.5+i*10)*y)
        ctx.setFontSize(6*y)
        ctx.fillText('I', 42.5*x, (35+10*i)*y)
        ctx.setFontSize(3*y)
        ctx.fillText(i, 44*x, (35+10*i)*y)
    }else{
      ctx.strokeRect(70*x,(35+(i-4)*20)*y,5*x,5*y)
      ctx.moveTo(60*x,(37.5+(i-4)*20)*y)
      ctx.lineTo(70*x,(37.5+(i-4)*20)*y)
        ctx.setFontSize(6*y)
        ctx.fillText('Y', 56.5*x, (40+20*(i-4))*y)
        ctx.setFontSize(3*y)
        ctx.fillText(i-4, 58*x, (40+20*(i-4))*y)
    }
  }
  ctx.stroke()
}
/* 4线-2线优先编码器样式显示控制 */
function fourtwocirControl(A,B,C,D,E,F){
  fourtwocir()
  discol(25,30,A)
  discol(25,40,B)
  discol(25,50,C)
  discol(25,60,D)
  discol(70,35,E)
  discol(70,55,F)
  ctx.draw()
}
/* 3-8译码器框图 */
function threeeightcir(){
  ctx.strokeRect(40*x,20*y,20*x,60*y)
  ctx.setTextAlign('center')
  for(var i=0;i<3;i++){
    ctx.strokeRect(25*x,(22.5+7.5*i)*y,5*x,5*y)
    ctx.moveTo(30*x,(25+7.5*i)*y)
    ctx.lineTo(40*x,(25+7.5*i)*y)
    ctx.setFontSize(6*y)
    ctx.fillText('A', 42.5*x, (27+7.5*i)*y)
    ctx.setFontSize(3*y)
    ctx.fillText(i, 45.2*x, (27.5+7.5*i)*y)
  }
  for(var i=0;i<3;i++){
    ctx.strokeRect(25*x,(60+7.5*i)*y,5*x,5*y)
    ctx.setFontSize(6*y)
    ctx.fillText('E', 42.5*x, (64.5+7.5*i)*y)
    ctx.setFontSize(3*y)
    ctx.fillText(3-i, 45.2*x, (65+7.5*i)*y)
  }
  ctx.moveTo(30*x,62.5*y)
  ctx.lineTo(40*x,62.5*y)
  for(var i=0;i<2;i++){
    ctx.moveTo(30*x,(70+7.5*i)*y)
    ctx.lineTo(37.5*x,(70+7.5*i)*y)
    ctx.arc(38.75*x,(70+7.5*i)*y,1.25*x,1*Math.PI,3.5*Math.PI)
    ctx.setFontSize(4.5*y)
    ctx.fillText('–', 42.5*x, (67.5+7.5*i)*y)
  }

  for(var i=0;i<8;i++){
    ctx.strokeRect(70*x,(22.5+7.5*i)*y,5*x,5*y)
    ctx.moveTo(62.5*x,(25+7.5*i)*y)
    ctx.lineTo(70*x,(25+7.5*i)*y)
    ctx.arc(61.25*x,(25+7.5*i)*y,1.25*x,0,2.5*Math.PI)
    ctx.setFontSize(6*y)
    ctx.fillText('Y', 56.3*x, (27+7.5*i)*y)
    ctx.setFontSize(5*y)
    ctx.fillText('–', 56.3*x, (23+7.5*i)*y)
    ctx.setFontSize(3*y)
    ctx.fillText(i, 58.2*x, (27.2+7.5*i)*y)
  }
  ctx.stroke()
}
/* 3-8译码器样式显示控制 */
function threeeightcirControl(A,B,C,D,E,F,G,H,I,J,K,L,M,N){
      threeeightcir()
        discol(25,22.5,A);
        discol(25,30,B);
        discol(25,37.5,C);
      
        discol(25,60,D);
        discol(25,60+7.5,E);
        discol(25,75,F);
      
        discol(70,22.5,G);
        discol(70,30,H);
        discol(70,37.5,I);
        discol(70,45,J);
        discol(70,52.5,K);
        discol(70,60,L);
        discol(70,67.5,M);
        discol(70,75,N);
      ctx.draw()
}
/* 七段显示译码器框图 */
function sevendisplaycir(){ 
  ctx.strokeRect(30*x,25*y,20*x,55*y)
  ctx.strokeRect(55*x,25*y,30*x,30*y)
  ctx.setTextAlign('center')
  for(var i=0;i<4;i++){
    ctx.strokeRect(15*x,(30+10*i)*y,5*x,5*y)
    ctx.moveTo(20*x,(32.5+10*i)*y)
    ctx.lineTo(30*x,(32.5+10*i)*y)
    ctx.moveTo(50*x,(30+7.5*i)*y)
    ctx.lineTo(55*x,(30+7.5*i)*y)
      /* 框图上所显示字母 */
      ctx.setFontSize(6*y)
      ctx.fillText('D', 32.5*x, (35+10*i)*y)
      ctx.fillText(String.fromCharCode('a'.charCodeAt(0) + i), 47.5*x, (32+7.5*i)*y)
      ctx.setFontSize(3*y)
      ctx.fillText(i, 35.5*x, (35+10*i)*y)
      ctx.setFontSize(5*y)
      ctx.fillText(String.fromCharCode('a'.charCodeAt(0) + i), 57.5*x, (31.6+7.5*i)*y)
  }
  for(var i=0;i<3;i++){
    ctx.moveTo(50*x,(60+7.5*i)*y)
    ctx.lineTo((65+7.5*i)*x,(60+7.5*i)*y)
    ctx.moveTo((65+7.5*i)*x,55*y)
    ctx.lineTo((65+7.5*i)*x,(60+7.5*i)*y)
    ctx.setFontSize(6*y)
    ctx.fillText(String.fromCharCode('e'.charCodeAt(0) + i), 47.5*x, (62.5+7.5*i)*y)
    ctx.setFontSize(5*y)
    ctx.fillText(String.fromCharCode('e'.charCodeAt(0) + i), (65+7.5*i)*x, 54*y)
    /* 绘制七段显示译码器的led */
    ctx.moveTo(66*x,(27.5+10*i)*y)
    ctx.lineTo(67*x,(26.5+10*i)*y)
    ctx.lineTo(78*x,(26.5+10*i)*y)
    ctx.lineTo(79*x,(27.5+10*i)*y)
    ctx.lineTo(78*x,(28.5+10*i)*y)
    ctx.lineTo(67*x,(28.5+10*i)*y)
    ctx.lineTo(66*x,(27.5+10*i)*y)
  }
  for(var i=0;i<2;i++){
    ctx.moveTo(66*x,(27.5+10*i)*y)
    ctx.lineTo(65*x,(28.5+10*i)*y)
    ctx.lineTo(65*x,(36.5+10*i)*y)
    ctx.lineTo(66*x,(37.5+10*i)*y)
    ctx.lineTo(67*x,(36.5+10*i)*y)
    ctx.lineTo(67*x,(28.5+10*i)*y)
    ctx.lineTo(66*x,(27.5+10*i)*y)

    ctx.moveTo(79*x,(27.5+10*i)*y)
    ctx.lineTo(78*x,(28.5+10*i)*y)
    ctx.lineTo(78*x,(36.5+10*i)*y)
    ctx.lineTo(79*x,(37.5+10*i)*y)
    ctx.lineTo(80*x,(36.5+10*i)*y)
    ctx.lineTo(80*x,(28.5+10*i)*y)
    ctx.lineTo(79*x,(27.5+10*i)*y)
  }
  ctx.stroke()
}
/* 七段显示译码器显示控制 */
function sevendisplaycirControl(A,B,C,D,E,F,G,H,I,J,K){
  sevendisplaycir()
  discol(15,30,A)
  discol(15,40,B)
  discol(15,50,C)
  discol(15,60,D)
  if(E==1){
    ctx.beginPath()
    ctx.moveTo(66*x,27.5*y)
    ctx.lineTo(67*x,26.5*y)
    ctx.lineTo(78*x,26.5*y)
    ctx.lineTo(79*x,27.5*y)
    ctx.lineTo(78*x,28.5*y)
    ctx.lineTo(67*x,28.5*y)
    ctx.lineTo(66*x,27.5*y)
    ctx.setFillStyle('red')
    ctx.fill()
  }else{
    ctx.beginPath()
    ctx.moveTo(66*x,27.5*y)
    ctx.lineTo(67*x,26.5*y)
    ctx.lineTo(78*x,26.5*y)
    ctx.lineTo(79*x,27.5*y)
    ctx.lineTo(78*x,28.5*y)
    ctx.lineTo(67*x,28.5*y)
    ctx.lineTo(66*x,27.5*y)
    ctx.setFillStyle('LightSteelBlue')
    ctx.fill()
  }
  if(F==1){
    ctx.beginPath()
    ctx.moveTo(79*x,27.5*y)
    ctx.lineTo(78*x,28.5*y)
    ctx.lineTo(78*x,36.5*y)
    ctx.lineTo(79*x,37.5*y)
    ctx.lineTo(80*x,36.5*y)
    ctx.lineTo(80*x,28.5*y)
    ctx.lineTo(79*x,27.5*y)
    ctx.setFillStyle('red')
    ctx.fill()
  }else{
    ctx.beginPath()
    ctx.moveTo(79*x,27.5*y)
    ctx.lineTo(78*x,28.5*y)
    ctx.lineTo(78*x,36.5*y)
    ctx.lineTo(79*x,37.5*y)
    ctx.lineTo(80*x,36.5*y)
    ctx.lineTo(80*x,28.5*y)
    ctx.lineTo(79*x,27.5*y)
    ctx.setFillStyle('LightSteelBlue')
    ctx.fill()
  }
  if(G==1){
    ctx.beginPath()
    ctx.moveTo(79*x,37.5*y)
    ctx.lineTo(78*x,38.5*y)
    ctx.lineTo(78*x,46.5*y)
    ctx.lineTo(79*x,47.5*y)
    ctx.lineTo(80*x,46.5*y)
    ctx.lineTo(80*x,38.5*y)
    ctx.lineTo(79*x,37.5*y)
    ctx.setFillStyle('red')
    ctx.fill()
  }else{
    ctx.beginPath()
    ctx.moveTo(79*x,37.5*y)
    ctx.lineTo(78*x,38.5*y)
    ctx.lineTo(78*x,46.5*y)
    ctx.lineTo(79*x,47.5*y)
    ctx.lineTo(80*x,46.5*y)
    ctx.lineTo(80*x,38.5*y)
    ctx.lineTo(79*x,37.5*y)
    ctx.setFillStyle('LightSteelBlue')
    ctx.fill()
  }
  if(H==1){
    ctx.beginPath()
    ctx.moveTo(66*x,47.5*y)
    ctx.lineTo(67*x,46.5*y)
    ctx.lineTo(78*x,46.5*y)
    ctx.lineTo(79*x,47.5*y)
    ctx.lineTo(78*x,48.5*y)
    ctx.lineTo(67*x,48.5*y)
    ctx.lineTo(66*x,47.5*y)
    ctx.setFillStyle('red')
    ctx.fill()
  }else{
    ctx.beginPath()
    ctx.moveTo(66*x,47.5*y)
    ctx.lineTo(67*x,46.5*y)
    ctx.lineTo(78*x,46.5*y)
    ctx.lineTo(79*x,47.5*y)
    ctx.lineTo(78*x,48.5*y)
    ctx.lineTo(67*x,48.5*y)
    ctx.lineTo(66*x,47.5*y)
    ctx.setFillStyle('LightSteelBlue')
    ctx.fill()
  }
  if(I==1){
    ctx.beginPath()
    ctx.moveTo(66*x,37.5*y)
    ctx.lineTo(65*x,38.5*y)
    ctx.lineTo(65*x,46.5*y)
    ctx.lineTo(66*x,47.5*y)
    ctx.lineTo(67*x,46.5*y)
    ctx.lineTo(67*x,38.5*y)
    ctx.lineTo(66*x,37.5*y)
    ctx.setFillStyle('red')
    ctx.fill()
  }else{
    ctx.beginPath()
    ctx.moveTo(66*x,37.5*y)
    ctx.lineTo(65*x,38.5*y)
    ctx.lineTo(65*x,46.5*y)
    ctx.lineTo(66*x,47.5*y)
    ctx.lineTo(67*x,46.5*y)
    ctx.lineTo(67*x,38.5*y)
    ctx.lineTo(66*x,37.5*y)
    ctx.setFillStyle('LightSteelBlue')
    ctx.fill()
  }
  if(J==1){
    ctx.beginPath()
    ctx.moveTo(66*x,27.5*y)
    ctx.lineTo(65*x,28.5*y)
    ctx.lineTo(65*x,36.5*y)
    ctx.lineTo(66*x,37.5*y)
    ctx.lineTo(67*x,36.5*y)
    ctx.lineTo(67*x,28.5*y)
    ctx.lineTo(66*x,27.5*y)
    ctx.setFillStyle('red')
    ctx.fill()
  }else{
    ctx.beginPath()
    ctx.moveTo(66*x,27.5*y)
    ctx.lineTo(65*x,28.5*y)
    ctx.lineTo(65*x,36.5*y)
    ctx.lineTo(66*x,37.5*y)
    ctx.lineTo(67*x,36.5*y)
    ctx.lineTo(67*x,28.5*y)
    ctx.lineTo(66*x,27.5*y)
    ctx.setFillStyle('LightSteelBlue')
    ctx.fill()
  }
  if(K==1){
    ctx.beginPath()
    ctx.moveTo(66*x,37.5*y)
    ctx.lineTo(67*x,36.5*y)
    ctx.lineTo(78*x,36.5*y)
    ctx.lineTo(79*x,37.5*y)
    ctx.lineTo(78*x,38.5*y)
    ctx.lineTo(67*x,38.5*y)
    ctx.lineTo(66*x,37.5*y)
    ctx.setFillStyle('red')
    ctx.fill()
  }else{
    ctx.beginPath()
    ctx.moveTo(66*x,37.5*y)
    ctx.lineTo(67*x,36.5*y)
    ctx.lineTo(78*x,36.5*y)
    ctx.lineTo(79*x,37.5*y)
    ctx.lineTo(78*x,38.5*y)
    ctx.lineTo(67*x,38.5*y)
    ctx.lineTo(66*x,37.5*y)
    ctx.setFillStyle('LightSteelBlue')
    ctx.fill()
  }
  ctx.setFillStyle('black')
  ctx.draw()
}
/* 4选1数据选择器框图 */
function fourtoonecir(){
  ctx.strokeRect(40*x,20*y,25*x,40*y)
  ctx.setTextAlign('center')
  for(var i=0;i<4;i++){
    ctx.strokeRect(25*x,(22.5+7.5*i)*y,5*x,5*y)
    ctx.moveTo(30*x,(25+7.5*i)*y)
    ctx.lineTo(40*x,(25+7.5*i)*y)
    ctx.setFontSize(6*y)
    ctx.fillText('I', 42.5*x, (27+7.5*i)*y)
    ctx.setFontSize(3*y)
    ctx.fillText(i, 45.2*x, (27.5+7.5*i)*y)
  }
  for(var i=0;i<2;i++){
    ctx.strokeRect((50+10*i)*x,70*y,5*x,5*y)
    ctx.moveTo((52.5+10*i)*x,60*y)
    ctx.lineTo((52.5+10*i)*x,70*y)
    ctx.setFontSize(6*y)
    ctx.fillText('S', (52.5+9*i)*x, 59.5*y)
    ctx.setFontSize(3*y)
    ctx.fillText(i, (55+9*i)*x, 59.5*y)
  }
    ctx.strokeRect(75*x,25*y,5*x,5*y)
    ctx.moveTo(65*x,27.5*y)
    ctx.lineTo(75*x,27.5*y)
    ctx.setFontSize(6*y)
    ctx.fillText('Y', 62*x, 29.5*y)
  ctx.stroke()
}
/* 4选1数据选择器显示控制 */
function fourtoonecirControl(A,B,C,D,E,F,G){
  fourtoonecir()
  discol(25,22.5,A);
  discol(25,30,B);
  discol(25,37.5,C);
  discol(25,45,D);
  discol(50,70,E);
  discol(60,70,F);
  discol(75,25,G);
  ctx.draw()
}
/* 数值比较器框图 */
function comparecir(){
  ctx.strokeRect(35*x,35*y,30*x,30*y)
  ctx.setTextAlign('center')
  for(var i=0;i<2;i++){
    ctx.strokeRect(20*x,(40+15*i)*y,5*x,5*y)
    ctx.moveTo(25*x,(42.5+15*i)*y)
    ctx.lineTo(35*x,(42.5+15*i)*y)
    ctx.setFontSize(6*y)
    ctx.fillText(String.fromCharCode('B'.charCodeAt(0) - i), 38*x, (45+15*i)*y)
  }
  for(var i=0;i<3;i++){
    ctx.strokeRect(55*x,(35+10*i)*y,10*x,10*y)
    ctx.strokeRect(75*x,(37.5+10*i)*y,5*x,5*y)
    ctx.moveTo(65*x,(40+10*i)*y)
    ctx.lineTo(75*x,(40+10*i)*y)
    ctx.setFontSize(5*y)
    ctx.fillText('F', 57.5*x, (41.5+10*i)*y)
    ctx.setFontSize(2.8*y)
    ctx.fillText('A   B', 61.5*x, (41.5+10*i)*y)
    ctx.fillText(String.fromCharCode('>'.charCodeAt(0) - i), 61.5*x, (41.5+10*i)*y)
  }
  ctx.stroke()
}
/* 数值比较器显示控制 */
function comparecirControl(A,B,C,D,E){
  comparecir()
  discol(20,40,A)
  discol(20,55,B)
  discol(75,37.5,C)
  discol(75,47.5,D)
  discol(75,57.5,E)
  ctx.draw()
}
/* 加法器框图 */
function addcir(){
  ctx.strokeRect(40*x,32.5*y,20*x,35*y)
  ctx.setTextAlign('center')
  for(var i=0;i<3;i++){
    ctx.strokeRect(25*x,(35+12.5*i)*y,5*x,5*y)
    ctx.moveTo(30*x,(37.5+12.5*i)*y)
    ctx.lineTo(40*x,(37.5+12.5*i)*y)
    ctx.setFontSize(5.5*y)
    ctx.fillText(String.fromCharCode('A'.charCodeAt(0) + i), 43*x, (40+12.5*i)*y)
  }
    ctx.setFontSize(3*y)
    ctx.fillText('in', 46.5*x, 65*y)
  for(var i=0;i<2;i++){
    ctx.strokeRect(70*x,(35+25*i)*y,5*x,5*y)
    ctx.moveTo(60*x,(37.5+25*i)*y)
    ctx.lineTo(70*x,(37.5+25*i)*y)
    ctx.setFontSize(5.5*y)
    ctx.fillText(String.fromCharCode('S'.charCodeAt(0) - 16*i), 56.5*x, (40+25*i)*y)
  }
  ctx.stroke()
}
/* 加法器显示控制 */
function addcirControl(A,B,C,D,E){
  addcir()
  discol(25,35,A)
  discol(25,47.5,B)
  discol(25,60,C)
  discol(70,35,D)
  discol(70,60,E)
  ctx.draw()
}
/* 4位CMOS寄存器框图 */
function registercir(){
  ctx.strokeRect(25*x,40*y,65*x,20*y)
  ctx.setTextAlign('center')
  for(var i=0;i<4;i++){
    ctx.strokeRect((30+15*i)*x,25*y,5*x,5*y)
    ctx.moveTo((32.5+15*i)*x,30*y)
    ctx.lineTo((32.5+15*i)*x,40*y)
    ctx.strokeRect((35+15*i)*x,70*y,5*x,5*y)
    ctx.moveTo((37.5+15*i)*x,60*y)
    ctx.lineTo((37.5+15*i)*x,70*y)
    ctx.setFontSize(5*y)
    ctx.fillText('D', (32.5+15*i)*x,45*y)
    ctx.fillText('Q', (37.5+15*i)*x,59*y)
    ctx.setFontSize(3*y)
    ctx.fillText(i, (35.5+15*i)*x,45*y)
    ctx.fillText(i, (40.5+15*i)*x,59*y)
  }
  for(var i=0;i<2;i++){
    ctx.strokeRect(10*x,(45+10*i)*y,5*x,5*y)
    ctx.moveTo(15*x,(47.5+10*i)*y)
    ctx.lineTo((25-2*i)*x,(47.5+10*i)*y)
  }
  ctx.arc(24*x,57.5*y,1*x,1*Math.PI,3.5*Math.PI)
  ctx.setFontSize(4*y)
  ctx.fillText('CP', 28*x,49*y)
  ctx.fillText('OE', 28*x,59*y)
  ctx.fillText('—', 28*x,56.5*y)
  ctx.stroke()
}
/* 4位CMOS寄存器显示控制 */
function registercirControl(A,B,C,D,E,F,G,H,I,J){
  registercir()
  discol(10,45,A)
  discol(10,55,B)
  discol(30,25,C)
  discol(45,25,D)
  discol(60,25,E)
  discol(75,25,F)
  discol(35,70,G)
  discol(50,70,H)
  discol(65,70,I)
  discol(80,70,J)
  ctx.draw()
}
/* 移位寄存器框图 */
function addshiftcir(){
  ctx.strokeRect(25*x,40*y,65*x,20*y)
  ctx.setTextAlign('center')
  for(var i=0;i<8;i++){
    ctx.strokeRect((30+7.5*i)*x,25*y,5*x,5*y)
    ctx.moveTo((32.5+7.5*i)*x,30*y)
    ctx.lineTo((32.5+7.5*i)*x,40*y)
    ctx.setFontSize(5*y)
    ctx.fillText('Q', (32.5+7.5*i)*x,45*y)
    ctx.setFontSize(3*y)
    ctx.fillText(i, (35.5+7.5*i)*x,45*y)
  }
  for(var i=0;i<2;i++){
    ctx.strokeRect(10*x,(45+10*i)*y,5*x,5*y)
    ctx.moveTo(15*x,(47.5+10*i)*y)
    ctx.lineTo(25*x,(47.5+10*i)*y)
  }
  ctx.moveTo(25*x,56*y)
  ctx.lineTo(27*x,57.5*y)
  ctx.lineTo(25*x,59*y)
  ctx.setFontSize(5*y)
  ctx.fillText('D', 28*x,49*y)
  ctx.fillText(' CP', 30*x,59.3*y)
  ctx.stroke()
}
/* 移位寄存器显示控制 */
function addshiftcirControl(A,B,C,D,E,F,G,H,I,J){
  addshiftcir()
  discol(10,45,A)
  discol(10,55,B)
  discol(30,25,C)
  discol(37.5,25,D)
  discol(45,25,E)
  discol(52.5,25,F)
  discol(60,25,G)
  discol(67.5,25,H)
  discol(75,25,I)
  discol(82.5,25,J)
  ctx.draw()
}
/* 计数器框图 */
function tallycir(){
  ctx.strokeRect(40*x,27.5*y,25*x,40*y)
  ctx.setTextAlign('center')
  for(var i=0;i<2;i++){
    ctx.strokeRect(25*x,(35+20*i)*y,5*x,5*y)
    ctx.moveTo(30*x,(37.5+20*i)*y)
    ctx.lineTo(40*x,(37.5+20*i)*y)
  }
  ctx.moveTo(40*x,36*y)
  ctx.lineTo(42*x,37.5*y)
  ctx.lineTo(40*x,39*y)
  ctx.setFontSize(5*y)
    ctx.fillText(' CP', 45*x, 39.5*y)
    ctx.fillText('CR', 44*x, 59*y)
  for(var i=0;i<4;i++){
    ctx.strokeRect(75*x,(30+10*i)*y,5*x,5*y)
    ctx.moveTo(65*x,(32.5+10*i)*y)
    ctx.lineTo(75*x,(32.5+10*i)*y)
    ctx.setFontSize(5*y)
      ctx.fillText('Q', 60.5*x, (35+10*i)*y)
      ctx.setFontSize(3*y)
      ctx.fillText(i, 63.5*x, (35+10*i)*y)
  }
  ctx.stroke()
}
/* 计数器显示控制 */
function tallycirControl(A,B,C,D,E,F){
  tallycir()
  discol(25,35,A)
  discol(25,55,B)
  discol(75,30,C)
  discol(75,40,D)
  discol(75,50,E)
  discol(75,60,F)
  ctx.draw()
}
Page({

  data: {
    show:false,
    overlay:true,
    /* 控制页面下部的滑动器件选择是否显示 */
    scroll_1:false,
    scroll_2:true,
    scroll_3:true,
    /* 控制真值表显示 */
    scroll_4:true,
    /* 真值表图片链接 */
    true_src:"https://s1.ax1x.com/2022/04/13/LKYs1g.jpg",
  },
  onLoad: function () {},

/* 开始打开小程序时在画布上面显示的内容 */
  onReady: function () {
    begin()
    ctx.draw()
  },
  /*生命周期函数--监听页面显示*/
  onShow: function () {
    ctx = wx.createCanvasContext('myCanvas', this)
  },
/* canvas仿真，点击画布各方框实现不同的状态 */
  tapSim:function(e){
    switch(tar_id){
      case'andCir':
      var num1=judg(25,42.5,e.touches[0].x,e.touches[0].y)/* 与门 或门第一个框输入判断 */
      var num2=judg(25,52.5,e.touches[0].x,e.touches[0].y)/* 与门 或门第二个框输入判断 */
      /* 与运算第一个盒子点击状态变化 */
      if(num1==1 && box_1==0 && box_2==0){
        box_1=1,box_2=0,box_3=0;
        andcir();
        discol(25,42.5,box_1);
        discol(25,52.5,box_2);
        discol(65,47.5,box_3);
        ctx.draw()
      }else if(num1==1 && box_1==1 && box_2==0){
        box_1=0,box_2=0,box_3=0;
        andcir();
        discol(25,42.5,box_1);
        discol(25,52.5,box_2);
        discol(65,47.5,box_3);
        ctx.draw()
      }else if(num1==1 && box_1==0 && box_2==1){
        box_1=1,box_2=1,box_3=1;
        andcir();
        discol(25,42.5,box_1);
        discol(25,52.5,box_2);
        discol(65,47.5,box_3);
        ctx.draw()
      }else if(num1==1 && box_1==1 && box_2==1){
        box_1=0,box_2=1,box_3=0;
        andcir();
        discol(25,42.5,box_1);
        discol(25,52.5,box_2);
        discol(65,47.5,box_3);
        ctx.draw()
      }
      /* 与运算第二个盒子点击状态变化 */
      if(num2==1 && box_1==0 && box_2==0){
        box_1=0,box_2=1,box_3=0;
        andcir();
        discol(25,42.5,box_1);
        discol(25,52.5,box_2);
        discol(65,47.5,box_3);
        ctx.draw()
      }else if(num2==1 && box_1==1 && box_2==0){
        box_1=1,box_2=1,box_3=1;
        andcir();
        discol(25,42.5,box_1);
        discol(25,52.5,box_2);
        discol(65,47.5,box_3);
        ctx.draw()
      }else if(num2==1 && box_1==0 && box_2==1){
        box_1=0,box_2=0,box_3=0;
        andcir();
        discol(25,42.5,box_1);
        discol(25,52.5,box_2);
        discol(65,47.5,box_3);
        ctx.draw()
      }else if(num2==1 && box_1==1 && box_2==1){
        box_1=1,box_2=0,box_3=0;
        andcir();
        discol(25,42.5,box_1);
        discol(25,52.5,box_2);
        discol(65,47.5,box_3);
        ctx.draw()
      }
      break
      case'orCir':
      var num1=judg(25,42.5,e.touches[0].x,e.touches[0].y)/* 与门 或门第一个框输入判断 */
      var num2=judg(25,52.5,e.touches[0].x,e.touches[0].y)/* 与门 或门第二个框输入判断 */
      /* 或运算第一个盒子点击状态变化 */
      if(num1==1 && box_1==0 && box_2==0){
        box_1=1,box_2=0,box_3=1;
        orcir();
        discol(25,42.5,box_1);
        discol(25,52.5,box_2);
        discol(65,47.5,box_3);
        ctx.draw()
      }else if(num1==1 && box_1==1 && box_2==0){
        box_1=0,box_2=0,box_3=0;
        orcir();
        discol(25,42.5,box_1);
        discol(25,52.5,box_2);
        discol(65,47.5,box_3);
        ctx.draw()
      }else if(num1==1 && box_1==0 && box_2==1){
        box_1=1,box_2=1,box_3=1;
        orcir();
        discol(25,42.5,box_1);
        discol(25,52.5,box_2);
        discol(65,47.5,box_3);
        ctx.draw()
      }else if(num1==1 && box_1==1 && box_2==1){
        box_1=0,box_2=1,box_3=1;
        orcir();
        discol(25,42.5,box_1);
        discol(25,52.5,box_2);
        discol(65,47.5,box_3);
        ctx.draw()
      }
      /* 或运算第二个盒子点击状态变化 */
      if(num2==1 && box_1==0 && box_2==0){
        box_1=0,box_2=1,box_3=1;
        orcir();
        discol(25,42.5,box_1);
        discol(25,52.5,box_2);
        discol(65,47.5,box_3);
        ctx.draw()
      }else if(num2==1 && box_1==1 && box_2==0){
        box_1=1,box_2=1,box_3=1;
        orcir();
        discol(25,42.5,box_1);
        discol(25,52.5,box_2);
        discol(65,47.5,box_3);
        ctx.draw()
      }else if(num2==1 && box_1==0 && box_2==1){
        box_1=0,box_2=0,box_3=0;
        orcir();
        discol(25,42.5,box_1);
        discol(25,52.5,box_2);
        discol(65,47.5,box_3);
        ctx.draw()
      }else if(num2==1 && box_1==1 && box_2==1){
        box_1=1,box_2=0,box_3=1;
        orcir();
        discol(25,42.5,box_1);
        discol(25,52.5,box_2);
        discol(65,47.5,box_3);
        ctx.draw()
      }
      break
      case'notCir':
      var num1=judg(30,47.5,e.touches[0].x,e.touches[0].y)/* 非门的判断输入 */
      if(num1==1 && box_1==0 && box_3==1){
        box_1=1,box_3=0;
        notcir();
        discol(30,47.5,box_1);
        discol(65,47.5,box_3);
        ctx.draw()
      }else if(num1==1 && box_1==1 && box_2==0){
        box_1=0,box_3=1;
        notcir();
        discol(30,47.5,box_1);
        discol(65,47.5,box_3);
        ctx.draw()
      }
      break
      case'threeEightCir':
      var num1=judg(25,22.5,e.touches[0].x,e.touches[0].y)
      var num2=judg(25,30,e.touches[0].x,e.touches[0].y)
      var num3=judg(25,37.5,e.touches[0].x,e.touches[0].y)
      var num4=judg(25,60,e.touches[0].x,e.touches[0].y)
      var num5=judg(25,67.5,e.touches[0].x,e.touches[0].y)
      var num6=judg(25,75,e.touches[0].x,e.touches[0].y)
      if(num4==1){
        if(box_4==1){
          box_4=0,box_7=1,box_8=1,box_9=1,box_10=1,box_11=1,box_12=1,box_13=1,box_14=1
        }else if(box_4==0){
          box_4=1
        }
      }else if(num5==1){
        if(box_5==1){
          box_5=0
        }else if(box_5==0){
          box_5=1,box_7=1,box_8=1,box_9=1,box_10=1,box_11=1,box_12=1,box_13=1,box_14=1
        }
      }else if(num6==1){
        if(box_6==1){
          box_6=0
        }else if(box_6==0){
          box_6=1,box_7=1,box_8=1,box_9=1,box_10=1,box_11=1,box_12=1,box_13=1,box_14=1
        }
      }

      if(num1==1 && (box_4==0 || box_5==1 || box_6==1)){
        if(box_1==1){
          box_1=0
        }else if(box_1==0){
          box_1=1
        }
      }else if(num2==1 && (box_4==0 || box_5==1 || box_6==1)){
        if(box_2==1){
          box_2=0
        }else if(box_2==0){
          box_2=1
        }
      }else if(num3==1 && (box_4==0 || box_5==1 || box_6==1)){
        if(box_3==1){
          box_3=0
        }else if(box_3==0){
          box_3=1
        }
      }

      if(box_4==1 && box_5==0 && box_6==0){
        if(box_1==0 && box_2==0 && box_3==0){
          box_7=0
        }else if(box_1==1 && box_2==0 && box_3==0){
          box_8=0
        }else if(box_1==0 && box_2==1 && box_3==0){
          box_9=0
        }else if(box_1==1 && box_2==1 && box_3==0){
          box_10=0
        }else if(box_1==0 && box_2==0 && box_3==1){
          box_11=0
        }else if(box_1==1 && box_2==0 && box_3==1){
          box_12=0
        }else if(box_1==0 && box_2==1 && box_3==1){
          box_13=0
        }else if(box_1==1 && box_2==1 && box_3==1){
          box_14=0
        }
      }

      if(num1==1 && box_4==1 && box_5==0 && box_6==0){
        if(box_1==0 && box_2==0 && box_3==0){
          box_1=1,box_2=0,box_3=0,box_4=1,box_5=0,box_6=0,box_7=1,box_8=0,box_9=1,box_10=1,box_11=1,box_12=1,box_13=1,box_14=1;
        }else if(box_1==1 && box_2==0 && box_3==0){
          box_1=0,box_2=0,box_3=0,box_4=1,box_5=0,box_6=0,box_7=0,box_8=1,box_9=1,box_10=1,box_11=1,box_12=1,box_13=1,box_14=1;
        }else if(box_1==0 && box_2==1 && box_3==0){
          box_1=1,box_2=1,box_3=0,box_4=1,box_5=0,box_6=0,box_7=1,box_8=1,box_9=1,box_10=0,box_11=1,box_12=1,box_13=1,box_14=1;
        }else if(box_1==1 && box_2==1 && box_3==0){
          box_1=0,box_2=1,box_3=0,box_4=1,box_5=0,box_6=0,box_7=1,box_8=1,box_9=0,box_10=1,box_11=1,box_12=1,box_13=1,box_14=1;
        }else if(box_1==0 && box_2==0 && box_3==1){
          box_1=1,box_2=0,box_3=1,box_4=1,box_5=0,box_6=0,box_7=1,box_8=1,box_9=1,box_10=1,box_11=1,box_12=0,box_13=1,box_14=1;
        }else if(box_1==1 && box_2==0 && box_3==1){
          box_1=0,box_2=0,box_3=1,box_4=1,box_5=0,box_6=0,box_7=1,box_8=1,box_9=1,box_10=1,box_11=0,box_12=1,box_13=1,box_14=1;
        }else if(box_1==0 && box_2==1 && box_3==1){
          box_1=1,box_2=1,box_3=1,box_4=1,box_5=0,box_6=0,box_7=1,box_8=1,box_9=1,box_10=1,box_11=1,box_12=1,box_13=1,box_14=0;
        }else if(box_1==1 && box_2==1 && box_3==1){
          box_1=0,box_2=1,box_3=1,box_4=1,box_5=0,box_6=0,box_7=1,box_8=1,box_9=1,box_10=1,box_11=1,box_12=1,box_13=0,box_14=1;
        }
      }else if(num2==1 && box_4==1 && box_5==0 && box_6==0){
        if(box_1==0 && box_2==0 && box_3==0){
          box_1=0,box_2=1,box_3=0,box_4=1,box_5=0,box_6=0,box_7=1,box_8=1,box_9=0,box_10=1,box_11=1,box_12=1,box_13=1,box_14=1;
        }else if(box_1==1 && box_2==0 && box_3==0){
          box_1=1,box_2=1,box_3=0,box_4=1,box_5=0,box_6=0,box_7=1,box_8=1,box_9=1,box_10=0,box_11=1,box_12=1,box_13=1,box_14=1;
        }else if(box_1==0 && box_2==1 && box_3==0){
          box_1=0,box_2=0,box_3=0,box_4=1,box_5=0,box_6=0,box_7=0,box_8=1,box_9=1,box_10=1,box_11=1,box_12=1,box_13=1,box_14=1;
        }else if(box_1==1 && box_2==1 && box_3==0){
          box_1=1,box_2=0,box_3=0,box_4=1,box_5=0,box_6=0,box_7=1,box_8=0,box_9=1,box_10=1,box_11=1,box_12=1,box_13=1,box_14=1;
        }else if(box_1==0 && box_2==0 && box_3==1){
          box_1=0,box_2=1,box_3=1,box_4=1,box_5=0,box_6=0,box_7=1,box_8=1,box_9=1,box_10=1,box_11=1,box_12=1,box_13=0,box_14=1;
        }else if(box_1==1 && box_2==0 && box_3==1){
          box_1=1,box_2=1,box_3=1,box_4=1,box_5=0,box_6=0,box_7=1,box_8=1,box_9=1,box_10=1,box_11=1,box_12=1,box_13=1,box_14=0;
        }else if(box_1==0 && box_2==1 && box_3==1){
          box_1=0,box_2=0,box_3=1,box_4=1,box_5=0,box_6=0,box_7=1,box_8=1,box_9=1,box_10=1,box_11=0,box_12=1,box_13=1,box_14=1;
        }else if(box_1==1 && box_2==1 && box_3==1){
          box_1=1,box_2=0,box_3=1,box_4=1,box_5=0,box_6=0,box_7=1,box_8=1,box_9=1,box_10=1,box_11=1,box_12=0,box_13=1,box_14=1;
        }
      }else if(num3==1 && box_4==1 && box_5==0 && box_6==0){
        if(box_1==0 && box_2==0 && box_3==0){
          box_1=0,box_2=0,box_3=1,box_4=1,box_5=0,box_6=0,box_7=1,box_8=1,box_9=1,box_10=1,box_11=0,box_12=1,box_13=1,box_14=1;
        }else if(box_1==1 && box_2==0 && box_3==0){
          box_1=1,box_2=0,box_3=1,box_4=1,box_5=0,box_6=0,box_7=1,box_8=1,box_9=1,box_10=1,box_11=1,box_12=0,box_13=1,box_14=1;
        }else if(box_1==0 && box_2==1 && box_3==0){
          box_1=0,box_2=1,box_3=1,box_4=1,box_5=0,box_6=0,box_7=1,box_8=1,box_9=1,box_10=1,box_11=1,box_12=1,box_13=0,box_14=1;
        }else if(box_1==1 && box_2==1 && box_3==0){
          box_1=1,box_2=1,box_3=1,box_4=1,box_5=0,box_6=0,box_7=1,box_8=1,box_9=1,box_10=1,box_11=1,box_12=1,box_13=1,box_14=0;
        }else if(box_1==0 && box_2==0 && box_3==1){
          box_1=0,box_2=0,box_3=0,box_4=1,box_5=0,box_6=0,box_7=0,box_8=1,box_9=1,box_10=1,box_11=1,box_12=1,box_13=1,box_14=1;
        }else if(box_1==1 && box_2==0 && box_3==1){
          box_1=1,box_2=0,box_3=0,box_4=1,box_5=0,box_6=0,box_7=1,box_8=0,box_9=1,box_10=1,box_11=1,box_12=1,box_13=1,box_14=1;
        }else if(box_1==0 && box_2==1 && box_3==1){
          box_1=0,box_2=1,box_3=0,box_4=1,box_5=0,box_6=0,box_7=1,box_8=1,box_9=0,box_10=1,box_11=1,box_12=1,box_13=1,box_14=1;
        }else if(box_1==1 && box_2==1 && box_3==1){
          box_1=1,box_2=1,box_3=0,box_4=1,box_5=0,box_6=0,box_7=1,box_8=1,box_9=1,box_10=0,box_11=1,box_12=1,box_13=1,box_14=1;
        }
      }
      threeeightcirControl(box_1,box_2,box_3,box_4,box_5,box_6,box_7,box_8,box_9,box_10,box_11,box_12,box_13,box_14)
      break
      case'fourTwoCir':
      var num1=judg(25,30,e.touches[0].x,e.touches[0].y)
      var num2=judg(25,40,e.touches[0].x,e.touches[0].y)
      var num3=judg(25,50,e.touches[0].x,e.touches[0].y)
      var num4=judg(25,60,e.touches[0].x,e.touches[0].y)
      if(num1==1){
        switch(box_1){
          case 0:
            box_1=1
            break
          case 1:
            box_1=0
            break
        }
      }else if(num2==1){
        switch(box_2){
          case 0:
            box_2=1
            break
          case 1:
            box_2=0
            break
        }
      }else if(num3==1){
        switch(box_3){
          case 0:
            box_3=1
            break
          case 1:
            box_3=0
            break
        }
      }else if(num4==1){
        switch(box_4){
          case 0:
            box_4=1
            break
          case 1:
            box_4=0
            break
        }
      }
      if(box_4==1){
        box_5=1,box_6=1
      }else if(box_3==1 && box_4==0){
        box_5=0,box_6=1
      }else if(box_2==1 && box_4==0 && box_3==0){
        box_5=1,box_6=0
      }else if(box_2==0 && box_4==0 && box_3==0){
        box_5=0,box_6=0
      }
      fourtwocirControl(box_1,box_2,box_3,box_4,box_5,box_6)
      break
      case'sevenDisplayCir':
      var num1=judg(15,30,e.touches[0].x,e.touches[0].y)
      var num2=judg(15,40,e.touches[0].x,e.touches[0].y)
      var num3=judg(15,50,e.touches[0].x,e.touches[0].y)
      var num4=judg(15,60,e.touches[0].x,e.touches[0].y)
      if(num1==1){
        switch(box_1){
          case 0:
            box_1=1
            break
          case 1:
            box_1=0
            break
        }
      }else if(num2==1){
        switch(box_2){
          case 0:
            box_2=1
            break
          case 1:
            box_2=0
            break
        }
      }else if(num3==1){
        switch(box_3){
          case 0:
            box_3=1
            break
          case 1:
            box_3=0
            break
        }
      }else if(num4==1){
        switch(box_4){
          case 0:
            box_4=1
            break
          case 1:
            box_4=0
            break
        }
      }
      if(box_1==0&&box_2==0&&box_3==0&&box_4==0){
        box_5=1,box_6=1,box_7=1,box_8=1,box_9=1,box_10=1,box_11=0
      }else if(box_1==1&&box_2==0&&box_3==0&&box_4==0){
        box_5=0,box_6=1,box_7=1,box_8=0,box_9=0,box_10=0,box_11=0
      }else if(box_1==0&&box_2==1&&box_3==0&&box_4==0){
        box_5=1,box_6=1,box_7=0,box_8=1,box_9=1,box_10=0,box_11=1
      }else if(box_1==1&&box_2==1&&box_3==0&&box_4==0){
        box_5=1,box_6=1,box_7=1,box_8=1,box_9=0,box_10=0,box_11=1
      }else if(box_1==0&&box_2==0&&box_3==1&&box_4==0){
        box_5=0,box_6=1,box_7=1,box_8=0,box_9=0,box_10=1,box_11=1
      }else if(box_1==1&&box_2==0&&box_3==1&&box_4==0){
        box_5=1,box_6=0,box_7=1,box_8=1,box_9=0,box_10=1,box_11=1
      }else if(box_1==0&&box_2==1&&box_3==1&&box_4==0){
        box_5=0,box_6=0,box_7=1,box_8=1,box_9=1,box_10=1,box_11=1
      }else if(box_1==1&&box_2==1&&box_3==1&&box_4==0){
        box_5=1,box_6=1,box_7=1,box_8=0,box_9=0,box_10=0,box_11=0
      }else if(box_1==0&&box_2==0&&box_3==0&&box_4==1){
        box_5=1,box_6=1,box_7=1,box_8=1,box_9=1,box_10=1,box_11=1
      }else if(box_1==1&&box_2==0&&box_3==0&&box_4==1){
        box_5=1,box_6=1,box_7=1,box_8=1,box_9=0,box_10=1,box_11=1
      }else if(box_4==1 && box_2==1||box_4==1&&box_3==1){
        box_5=0,box_6=0,box_7=0,box_8=0,box_9=0,box_10=0,box_11=0
      }
      sevendisplaycirControl(box_1,box_2,box_3,box_4,box_5,box_6,box_7,box_8,box_9,box_10,box_11)
      break
      case'fourToOneCir':
      var num1=judg(25,22.5,e.touches[0].x,e.touches[0].y)
      var num2=judg(25,30,e.touches[0].x,e.touches[0].y)
      var num3=judg(25,37.5,e.touches[0].x,e.touches[0].y)
      var num4=judg(25,45,e.touches[0].x,e.touches[0].y)
      var num5=judg(50,70,e.touches[0].x,e.touches[0].y)
      var num6=judg(60,70,e.touches[0].x,e.touches[0].y)
      if(num1==1){
        switch(box_1){
          case 0:
            box_1=1
            break
          case 1:
            box_1=0
            break
        }
      }else if(num2==1){
        switch(box_2){
          case 0:
            box_2=1
            break
          case 1:
            box_2=0
            break
        }
      }else if(num3==1){
        switch(box_3){
          case 0:
            box_3=1
            break
          case 1:
            box_3=0
            break
        }
      }else if(num4==1){
        switch(box_4){
          case 0:
            box_4=1
            break
          case 1:
            box_4=0
            break
        }
      }else if(num5==1){
        switch(box_5){
          case 0:
            box_5=1
            break
          case 1:
            box_5=0
            break
        }
      }else if(num6==1){
        switch(box_6){
          case 0:
            box_6=1
            break
          case 1:
            box_6=0
            break
        }
      }
      if(box_5==0&&box_6==0){
        box_7=box_1
      }else if(box_5==1&&box_6==0){
        box_7=box_2
      }else if(box_5==0&&box_6==1){
        box_7=box_3
      }else if(box_5==1&&box_6==1){
        box_7=box_4
      }
      fourtoonecirControl(box_1,box_2,box_3,box_4,box_5,box_6,box_7)
      break
      case'compareCir':
      var num1=judg(20,40,e.touches[0].x,e.touches[0].y)
      var num2=judg(20,55,e.touches[0].x,e.touches[0].y)
      if(num1==1){
        switch(box_1){
          case 0:
            box_1=1
            break
          case 1:
            box_1=0
            break
        }
      }else if(num2==1){
          switch(box_2){
            case 0:
              box_2=1
              break
            case 1:
              box_2=0
              break
          }
      }
      if(box_1==0&&box_2==0){
        box_3=0,box_4=1,box_5=0
      }else if(box_1==1&&box_2==1){
        box_3=0,box_4=1,box_5=0
      }else if(box_1==0&&box_2==1){
        box_3=1,box_4=0,box_5=0
      }else if(box_1==1&&box_2==0){
        box_3=0,box_4=0,box_5=1
      }
      comparecirControl(box_1,box_2,box_3,box_4,box_5)
      break
      case'addCir':
      var num1=judg(25,35,e.touches[0].x,e.touches[0].y)
      var num2=judg(25,47.5,e.touches[0].x,e.touches[0].y)
      var num3=judg(25,60,e.touches[0].x,e.touches[0].y)
      if(num1==1){
        switch(box_1){
          case 0:
            box_1=1
            break
          case 1:
            box_1=0
            break
        }
      }else if(num2==1){
          switch(box_2){
            case 0:
              box_2=1
              break
            case 1:
              box_2=0
              break
          }
      }else if(num3==1){
        switch(box_3){
          case 0:
            box_3=1
            break
          case 1:
            box_3=0
            break
        }
      }
      switch(box_1){
        case 0:
          switch(box_2){
            case 0:
              switch(box_3){
                case 0:
                  box_4=0,box_5=0
                  break
                case 1:
                  box_4=1,box_5=0
                  break
              }
              break
            case 1:
              switch(box_3){
                case 0:
                  box_4=1,box_5=0
                  break
                case 1:
                  box_4=0,box_5=1
                  break
              }
              break
          }
          break
        case 1:
          switch(box_2){
            case 0:
              switch(box_3){
                case 0:
                  box_4=1,box_5=0
                  break
                case 1:
                  box_4=0,box_5=1
                  break
              }
              break
            case 1:
              switch(box_3){
                case 0:
                  box_4=0,box_5=1
                  break
                case 1:
                  box_4=1,box_5=1
                  break
              }
              break
          }
          break
      }
      addcirControl(box_1,box_2,box_3,box_4,box_5)
      break
      case'registerCir':
      var num1=judg(10,45,e.touches[0].x,e.touches[0].y)
      var num2=judg(10,55,e.touches[0].x,e.touches[0].y)
      var num3=judg(30,25,e.touches[0].x,e.touches[0].y)
      var num4=judg(45,25,e.touches[0].x,e.touches[0].y)
      var num5=judg(60,25,e.touches[0].x,e.touches[0].y)
      var num6=judg(75,25,e.touches[0].x,e.touches[0].y)
      if(num1==1){
        switch(box_1){
          case 0:
            box_1=1
            if(box_2==0){
              box_7=box_3,box_8=box_4,box_9=box_5,box_10=box_6
            }
            break
          case 1:
            box_1=0
            break
        }
      }else if(num2==1){
        switch(box_2){
          case 0:
            box_2=1
            break
          case 1:
            box_2=0
            break
        }
      }else if(num3==1){
        switch(box_3){
          case 0:
            box_3=1
            break
          case 1:
            box_3=0
            break
        }
      }else if(num4==1){
        switch(box_4){
          case 0:
            box_4=1
            break
          case 1:
            box_4=0
            break
        }
      }else if(num5==1){
        switch(box_5){
          case 0:
            box_5=1
            break
          case 1:
            box_5=0
            break
        }
      }else if(num6==1){
        switch(box_6){
          case 0:
            box_6=1
            break
          case 1:
            box_6=0
            break
        }
      }
      registercirControl(box_1,box_2,box_3,box_4,box_5,box_6,box_7,box_8,box_9,box_10)
      break
      case'addShiftCir':
      var num1=judg(10,45,e.touches[0].x,e.touches[0].y)
      var num2=judg(10,55,e.touches[0].x,e.touches[0].y)
      if(num1==1){
        switch(box_1){
          case 0:
            box_1=1
            break
          case 1:
            box_1=0
            break
        }
      }else if(num2==1){
          switch(box_2){
            case 0:
              box_2=1
              box_10=box_9
              box_9=box_8
              box_8=box_7
              box_7=box_6
              box_6=box_5
              box_5=box_4
              box_4=box_3
              box_3=box_1
              break
            case 1:
              box_2=0
              break
          }
      }
      addshiftcirControl(box_1,box_2,box_3,box_4,box_5,box_6,box_7,box_8,box_9,box_10)
      break
      case'tallyCir':
      var num1=judg(25,35,e.touches[0].x,e.touches[0].y)
      var num2=judg(25,55,e.touches[0].x,e.touches[0].y)
      if(num1==1){
        switch(box_1){
          case 0:
            box_1=1
            if(box_2==0){
              tall++;
              if(tall%2==0){
                box_3=1
              }else{box_3=0}
              if(tall==3||tall==4||tall==7||tall==8||tall==11||tall==12||tall==15||tall==16){
                box_4=1
              }else{box_4=0}
              if(tall==8||tall==5||tall==6||tall==7||tall==13||tall==14||tall==15||tall==16){
                box_5=1
              }else{box_5=0}
              
              if(tall>8){
                box_6=1
              }else{box_6=0}
              if(tall==16){tall=0}
            }
            break
          case 1:
            box_1=0
            break
        }
      }else if(num2==1){
          switch(box_2){
            case 0:
              box_2=1
              box_3=0,box_4=0,box_5=0,box_6=0,tall=1
              break
            case 1:
              box_2=0
              break
          }
      }
      tallycirControl(box_1,box_2,box_3,box_4,box_5,box_6)
      break
    }
  },
/* 触发由底部向上的弹窗 */
  popup:function(e){
    begin()
    ctx.draw()
    this.setData({
      show:true,
      scroll_4:true
    })
    if(tar_id=='threeEightCir'||tar_id=='fourTwoCir'||tar_id=='sevenDisplayCir'||tar_id=='fourToOneCir'||tar_id=='compareCir'||tar_id=='addCir'){
    this.setData({
        scroll_1:true,
        scroll_2:false,
        scroll_3:true
        })
    }else if(tar_id=='andCir'||tar_id=='orCir'||tar_id=='notCir'){
        this.setData({
            scroll_1:false,
            scroll_2:true,
            scroll_3:true
            })
    }else if(tar_id=='registerCir'||tar_id=='addShiftCir'||tar_id=='tallyCir'){
        this.setData({
            scroll_1:true,
            scroll_2:true,
            scroll_3:false
            })
    }
    tar_id=0//解决弹窗弹出时点击画布会出现画面的BUG。
  },
/* 选择在页面下部的滑动窗口显示的电路类型 */
  select:function(e){
    switch(e.currentTarget.id) {
      case 'one':
        this.setData({
          scroll_1:false,
          scroll_2:true,
          scroll_3:true})
          break
      case 'two': 
      this.setData({
        scroll_1:true,
        scroll_2:false,
        scroll_3:true})
        break
      case 'three':
        this.setData({
          scroll_1:true,
          scroll_2:true,
          scroll_3:false})
        break
    }
    this.setData({
      show:false
    })
  },
/* 通过下部按钮选择在canvas画布上显示的不同类型的电路 */
  CirSelect:function(e){
    tar_id=e.currentTarget.id
    switch(e.currentTarget.id){
      case'andCir':
      andcir();
      discol(25,42.5,0);
      discol(25,52.5,0);
      discol(65,47.5,0);
      ctx.draw();
      box_1=0,box_2=0,box_3=0;
      break
      case'orCir':
      orcir();
      discol(25,42.5,0);
      discol(25,52.5,0);
      discol(65,47.5,0);
      ctx.draw()
      box_1=0,box_2=0,box_3=0;
      break
      case'notCir':
      notcir()
      discol(30,47.5,0);
      discol(65,47.5,1);
      ctx.draw()
      box_1=0,box_3=1;
      break
      case'threeEightCir':
      box_1=0,box_2=0,box_3=0,box_4=1,box_5=0,box_6=0,box_7=0,box_8=1,box_9=1,box_10=1,box_11=1,box_12=1,box_13=1,box_14=1;
      threeeightcirControl(box_1,box_2,box_3,box_4,box_5,box_6,box_7,box_8,box_9,box_10,box_11,box_12,box_13,box_14)
      break
      case'fourTwoCir':
      box_1=1,box_2=0,box_3=0,box_4=0,box_5=0,box_6=0;
      fourtwocirControl(box_1,box_2,box_3,box_4,box_5,box_6)
      break
      case'sevenDisplayCir':
      box_1=0,box_2=0,box_3=0,box_4=0,box_5=1,box_6=1,box_7=1,box_8=1,box_9=1,box_10=1,box_11=0
      sevendisplaycirControl(box_1,box_2,box_3,box_4,box_5,box_6,box_7,box_8,box_9,box_10,box_11)
      break
      case'fourToOneCir':
      box_1=0,box_2=0,box_3=0,box_4=0,box_5=0,box_6=0,box_7=0
      fourtoonecirControl(box_1,box_2,box_3,box_4,box_5,box_6,box_7)
      break
      case'compareCir':
      box_1=0,box_2=0,box_3=0,box_4=1,box_5=0
      comparecirControl(box_1,box_2,box_3,box_4,box_5)
      break
      case'addCir':
      box_1=0,box_2=0,box_3=0,box_4=0,box_5=0
      addcirControl(box_1,box_2,box_3,box_4,box_5)
      break
      case'registerCir':
      box_1=0,box_2=0,box_3=1,box_4=0,box_5=1,box_6=0,box_7=0,box_8=0,box_9=0,box_10=0
      registercirControl(box_1,box_2,box_3,box_4,box_5,box_6,box_7,box_8,box_9,box_10)
      break
      case'addShiftCir':
      box_1=0,box_2=0,box_3=1,box_4=1,box_5=1,box_6=1,box_7=0,box_8=0,box_9=0,box_10=0
      addshiftcirControl(box_1,box_2,box_3,box_4,box_5,box_6,box_7,box_8,box_9,box_10)
      break
      case'tallyCir':
      box_1=0,box_2=0,box_3=0,box_4=0,box_5=0,box_6=0
      tallycirControl(box_1,box_2,box_3,box_4,box_5,box_6)
      break
    }
  },
  /* 用户点击右上角分享 */
  onShareAppMessage: function () {

    },
  /* 真值表显示 */
  true_table:function(){
    switch(tar_id){
        case'andCir':
        switch(this.data.scroll_4){
            case true:
                this.setData({
                    scroll_4:false,
                    scroll_1:true,
                    scroll_2:true,
                    scroll_3:true,
                    true_src:"https://s1.ax1x.com/2022/04/13/LMes74.jpg"
                })
                break
            case false:
                this.setData({
                    scroll_4:true,
                    scroll_1:false,
                    scroll_2:true,
                    scroll_3:true
                })
                break
        }
        break
        case'orCir':
        switch(this.data.scroll_4){
            case true:
                this.setData({
                    scroll_4:false,
                    scroll_1:true,
                    scroll_2:true,
                    scroll_3:true,
                    true_src:"https://s1.ax1x.com/2022/04/13/LMeghR.jpg"
                })
                break
            case false:
                this.setData({
                    scroll_4:true,
                    scroll_1:false,
                    scroll_2:true,
                    scroll_3:true
                })
                break
        }
        break
        case'notCir':
        switch(this.data.scroll_4){
            case true:
                this.setData({
                    scroll_4:false,
                    scroll_1:true,
                    scroll_2:true,
                    scroll_3:true,
                    true_src:"https://s1.ax1x.com/2022/04/13/LMecN9.jpg"
                })
                break
            case false:
                this.setData({
                    scroll_4:true,
                    scroll_1:false,
                    scroll_2:true,
                    scroll_3:true
                })
                break
        }
        break
        case'threeEightCir':
        switch(this.data.scroll_4){
            case true:
                this.setData({
                    scroll_4:false,
                    scroll_1:true,
                    scroll_2:true,
                    scroll_3:true,
                    true_src:"https://s1.ax1x.com/2022/04/13/LMerBF.jpg"
                })
                break
            case false:
                this.setData({
                    scroll_4:true,
                    scroll_1:true,
                    scroll_2:false,
                    scroll_3:true
                })
                break
        }
        break
        case'fourTwoCir':
        switch(this.data.scroll_4){
            case true:
                this.setData({
                    scroll_4:false,
                    scroll_1:true,
                    scroll_2:true,
                    scroll_3:true,
                    true_src:"https://s1.ax1x.com/2022/04/13/LMSsTf.jpg"
                })
                break
            case false:
                this.setData({
                    scroll_4:true,
                    scroll_1:true,
                    scroll_2:false,
                    scroll_3:true
                })
                break
        }
        break
        case'sevenDisplayCir':
        switch(this.data.scroll_4){
            case true:
                this.setData({
                    scroll_4:false,
                    scroll_1:true,
                    scroll_2:true,
                    scroll_3:true,
                    true_src:"https://s1.ax1x.com/2022/04/13/LKYs1g.jpg"
                })
                break
            case false:
                this.setData({
                    scroll_4:true,
                    scroll_1:true,
                    scroll_2:false,
                    scroll_3:true
                })
                break
        }
        break
        case'fourToOneCir':
        switch(this.data.scroll_4){
            case true:
                this.setData({
                    scroll_4:false,
                    scroll_1:true,
                    scroll_2:true,
                    scroll_3:true,
                    true_src:"https://s1.ax1x.com/2022/04/13/LMSDmt.jpg"
                })
                break
            case false:
                this.setData({
                    scroll_4:true,
                    scroll_1:true,
                    scroll_2:false,
                    scroll_3:true
                })
                break
        }
        break
        case'compareCir':
        switch(this.data.scroll_4){
            case true:
                this.setData({
                    scroll_4:false,
                    scroll_1:true,
                    scroll_2:true,
                    scroll_3:true,
                    true_src:"https://s1.ax1x.com/2022/04/13/LMSaSH.jpg"
                })
                break
            case false:
                this.setData({
                    scroll_4:true,
                    scroll_1:true,
                    scroll_2:false,
                    scroll_3:true
                })
                break
        }
        break
        case'addCir':
        switch(this.data.scroll_4){
            case true:
                this.setData({
                    scroll_4:false,
                    scroll_1:true,
                    scroll_2:true,
                    scroll_3:true,
                    true_src:"https://s1.ax1x.com/2022/04/13/LMSdld.jpg"
                })
                break
            case false:
                this.setData({
                    scroll_4:true,
                    scroll_1:true,
                    scroll_2:false,
                    scroll_3:true
                })
                break
        }
        break
        case'registerCir':
        switch(this.data.scroll_4){
            case true:
                this.setData({
                    scroll_4:false,
                    scroll_1:true,
                    scroll_2:true,
                    scroll_3:true,
                    true_src:"https://s1.ax1x.com/2022/04/13/LMiGGT.jpg"
                })
                break
            case false:
                this.setData({
                    scroll_4:true,
                    scroll_1:true,
                    scroll_2:true,
                    scroll_3:false
                })
                break
        }
        break
        case'addShiftCir':
        switch(this.data.scroll_4){
            case true:
                this.setData({
                    scroll_4:false,
                    scroll_1:true,
                    scroll_2:true,
                    scroll_3:true,
                    true_src:"https://s1.ax1x.com/2022/04/13/LMS0OI.jpg"
                })
                break
            case false:
                this.setData({
                    scroll_4:true,
                    scroll_1:true,
                    scroll_2:true,
                    scroll_3:false
                })
                break
        }
        break
        case'tallyCir':
        switch(this.data.scroll_4){
            case true:
                this.setData({
                    scroll_4:false,
                    scroll_1:true,
                    scroll_2:true,
                    scroll_3:true,
                    true_src:"https://s1.ax1x.com/2022/04/13/LMSr0P.jpg"
                })
                break
            case false:
                this.setData({
                    scroll_4:true,
                    scroll_1:true,
                    scroll_2:true,
                    scroll_3:false
                })
                break
        }
        break
    }
  }
})