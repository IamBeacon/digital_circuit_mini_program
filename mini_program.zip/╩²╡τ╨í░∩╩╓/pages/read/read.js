// pages/read.js
/* 
<h2 style="line-height: 2.8;text-align: center;" ></h2>
<p style="line-height: 1.8;"><strong></strong>：</p><br>
<p style="text-indent: 30px;line-height: 1.8;"></p><br>
<img src="" width="100%">
<hr />
*/
const htmlSnip1 =
`
<h2 style="line-height: 2.8;text-align: center;" >卡诺图</h2>

<p style="text-indent: 30px;line-height: 1.8;">卡诺图的每一个方格就是表示的一个一个的最小项，只要注意到这一点，使用起来就很简单了。</p><br>

<p style="line-height: 1.8;"><strong>卡诺图的构成：</strong>：</p><br>
<p style="text-indent: 30px;line-height: 1.8;">卡诺图是一种包含一些小方块的几何图形，图中每个小方块称为一个单元，每个单元对应一个最小项。两个相邻的最小项在卡诺图中也必须是相邻的。卡诺图中相邻的含义：</p><br>
<p style="text-indent: 30px;line-height: 1.8;">⛵<strong>几何相邻性</strong>，即几何位置上相邻，也就是左右紧挨着或者上下相接；</p><br>
<p style="text-indent: 30px;line-height: 1.8;">⛵<strong>对称相邻性</strong>，即图形中对称位置的单元是相邻的。</p><br>
<hr/>
<p style="text-indent: 30px;line-height: 1.8;">A是高位，BC是低位，000对应最小项m0，即/A/B/C，后面以此类推。</p><br>
<img src="https://pic1.zhimg.com/80/v2-ef968cf33cd2e7473b325e631ca90f74_720w.jpg" width="100%">
<img src="https://pic3.zhimg.com/80/v2-02936d99e6333a22d9e4a0e5410ef6da_720w.jpg" width="100%">
<p style="text-indent: 30px;line-height: 1.8;">一定要注意<strong>卡诺图的排列顺序</strong>，这里很容易出错。出错点可以参考下面的题目。</p><br>
<img src="https://pic1.zhimg.com/80/v2-c984f60318b06259364162fc642e342c_720w.jpg" width="100%">
<p style="text-indent: 30px;line-height: 1.8;">这里<strong>一定一定要注意，尤其是粉紫色</strong>。从下图可见，0和8对应的格子，只有A项是不同的，所以它们是相邻的，是可以合并的。</p><br>
<img src="https://pic2.zhimg.com/80/v2-10e7b02499efb04593f2c17ebcd83d29_720w.jpg" width="100%">
<p style="text-indent: 30px;line-height: 1.8;">知道了什么是卡诺图，下面来试着用卡诺图表示逻辑函数。</p><br>
<img src="https://pic1.zhimg.com/80/v2-3440d355ef24d1939b0e12d1b9856584_720w.jpg" width="100%">
<hr/>
<p style="line-height: 1.8;"><strong>在卡诺图上合并最小项的规则</strong>：</p><br>
<p style="line-height: 1.8;">
基础是要会画卡诺图并理解卡诺图上【相邻】的含义。<br>
合并最小项时牢记六个字：圈要少、圈最大（先少后大）。<br>
学完之后多做练习，找到那个feel。<br>
圈两个，消一个；圈四个，消两个；圈八个，消三个...<br>
这里只放PPT，不做多余讲解。</p><br>
<img src="https://pic4.zhimg.com/80/v2-4b79896fd0ec276db4366f429f06413b_720w.jpg" width="100%">
<img src="https://pic3.zhimg.com/80/v2-4ee6a6dcf704c61b4da5afbe09346b22_720w.jpg" width="100%">
<img src="https://pic1.zhimg.com/80/v2-bbd3d646e0097851d588a39e2bed8564_720w.jpg" width="100%">
<img src="https://pic1.zhimg.com/80/v2-2772ae215d02b5d0255fc3c006232290_720w.jpg" width="100%">
`
const htmlSnip2 =
`
<h2 style="line-height: 2.8;text-align: center;" >译码器</h2>
<p style="line-height: 1.8;"><strong>概述</strong>：</p><br>
<p style="text-indent: 30px;line-height: 1.8;">译码是编码的逆过程，在编码时，每一种二进制代码，都赋予了特定的含义，即都表示了一个确定的信号或者对象。把代码状态的特定含义“翻译”出来的过程叫做译码，实现译码操作的电路称为译码器。或者说，译码器是可以将输入二进制代码的状态翻译成输出信号，以表示其原来含义的电路。</p><br>
<img src="https://bkimg.cdn.bcebos.com/pic/3b292df5e0fe9925e8d8197334a85edf8db17138?x-bce-process=image/resize,m_lfit,w_440,limit_1/format,f_auto" width="100%">
<hr />
`
const htmlSnip3 =
`
<h2 style="line-height: 2.8;text-align: center;" >D触发器</h2>
<p style="line-height: 1.8;"><strong>简介</strong>：</p><br>
<p style="text-indent: 30px;line-height: 1.8;">D触发器是一个具有记忆功能的，具有两个稳定状态的信息存储器件，是构成多种时序电路的最基本逻辑单元，也是数字逻辑电路中一种重要的单元电路。</p><br>
<p style="text-indent: 30px;line-height: 1.8;">因此，D触发器在数字系统和计算机中有着广泛的应用。触发器具有两个稳定状态，即"0"和"1"，在一定的外界信号作用下，可以从一个稳定状态翻转到另一个稳定状态。</p><br>
<p style="text-indent: 30px;line-height: 1.8;">D触发器有集成触发器和门电路组成的触发器。触发方式有电平触发和边沿触发两种，前者在CP(时钟脉冲)=1时即可触发，后者多在CP的前沿（正跳变0→1）触发。</p><br>
<p style="text-indent: 30px;line-height: 1.8;">D触发器的次态取决于触发前D端的状态，即次态=D。因此，它具有置0、置1两种功能。</p><br>
<p style="text-indent: 30px;line-height: 1.8;">对于边沿D触发器，由于在CP=1期间电路具有维持阻塞作用，所以在CP=1期间，D端的数据状态变化，不会影响触发器的输出状态。</p><br>
<p style="text-indent: 30px;line-height: 1.8;">D触发器应用很广，可用做数字信号的寄存，移位寄存，分频和波形发生器等等。</p><br>
<img src="https://bkimg.cdn.bcebos.com/pic/4610b912c8fcc3ce5c99d7459245d688d43f206e?x-bce-process=image/resize,m_lfit,w_238,limit_1/format,f_auto" width="100%">
<hr />
`
Page({

    /**
     * 页面的初始数据
     */
    data: {
        htmlSnip1,
        htmlSnip2,
        htmlSnip3,
        article:0,
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        this.setData({
            text: options.text
          })
        if(this.data.text=='kanuotu'){
            this.setData({
                article: htmlSnip1
              })
        }else if(this.data.text=='yimaqi'){
            this.setData({
                article: htmlSnip2
              })
        }else if(this.data.text=='Dchufaqi'){
            this.setData({
                article: htmlSnip3
              })
        }
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})